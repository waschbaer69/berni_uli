#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sys/stat.h>
#include <fstream>
#include <sstream>

#define BUF 1024
#define QUEUE_SIZE 10


static std::string get_method(const std::string &string, char delimiter);

static inline int count_lines(const std::string &s);

static void handle_send(int client_fd, const std::string &request, const std::string &mailspool_path);

static void handle_list(int client_fd, const std::string &request, const std::string &mailspool_path);

static void handle_read(int client_fd, const std::string &request, const std::string &mailspool_path);

static void handle_del(int client_fd, const std::string &request, const std::string &mailspool_path);

static std::vector<std::string> parse_send(const std::string &string, char delimiter);

static std::vector<std::string> parse_list(const std::string &string, char delimiter);

static std::vector<std::string> parse_read(const std::string &string, char delimiter);

static std::vector<std::string> parse_del(const std::string &string, char delimiter);

static inline std::string &ltrim(std::string &s);

static inline std::string &rtrim(std::string &s);

static inline std::string &trim(std::string &s);


int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cout << "usage: ./server <port> <mailspool_directory>" << std::endl;
        return EXIT_FAILURE;
    }

    struct stat info{};

    if (stat(argv[2], &info) != 0) {
        std::cout << "Cannot access " << argv[2] << std::endl;
        return EXIT_FAILURE;
    } else if (!S_ISDIR(info.st_mode)) {
        std::cout << argv[2] << " is no directory" << std::endl;
        return EXIT_FAILURE;
    }

    if (argv[2][strlen(argv[2]) - 1] == '/') argv[2][strlen(argv[2]) - 1] = 0;

    std::string mailspool_path(argv[2]);

    uint16_t port;
    try {
        port = static_cast<uint16_t>(std::stoi(argv[1]));
    } catch (std::invalid_argument &e) {
        std::cout << "invalid port number" << std::endl;
        return EXIT_FAILURE;
    } catch (std::out_of_range &e) {
        std::cout << "invalid port number" << std::endl;
        return EXIT_FAILURE;
    }

    int server_socket_fd, client_socket_fd;
    struct sockaddr_in server_address{}, client_address{};

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(port);

    server_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket_fd < 0) {
        std::cerr << "error opening socket";
        return EXIT_FAILURE;
    }


    int enable = 1;
    if (setsockopt(server_socket_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable))) {
        std::cerr << "setsockopt(SO_REUSEADDR) failed";
        return EXIT_FAILURE;
    }

    if (bind(server_socket_fd, (struct sockaddr *) &server_address, sizeof(server_address)) != 0) {
        std::cerr << "bind error";
        return EXIT_FAILURE;
    }

    listen(server_socket_fd, QUEUE_SIZE);

    socklen_t address_len = sizeof(struct sockaddr_in);
    char buffer[BUF];

    while (true) {
        std::cout << "Waiting for connections on " << inet_ntoa(server_address.sin_addr) << ":" << port << "..."
                  << std::endl;
        client_socket_fd = accept(server_socket_fd, (struct sockaddr *) &client_address, &address_len);

        if (client_socket_fd > 0) {
            std::cout << "Client connected from " << inet_ntoa(client_address.sin_addr) << ":"
                      << ntohs(client_address.sin_port) << "..." << std::endl;
            strcpy(buffer, "Welcome to my server, Please enter your command:\n");
            send(client_socket_fd, buffer, strlen(buffer), 0);
        }

        std::string request;
        std::string method;

        while (true) {
            ssize_t size = recv(client_socket_fd, buffer, BUF - 1, 0);
            if (size > 0) {
                buffer[size] = '\0';
                request.append(buffer);

                if (method.empty()) method = get_method(request, '\n');
                int lines = count_lines(request);

                if (!method.empty()) {
                    request = ltrim(request);

                    if (method == "SEND") {
                        if (lines >= 5 && request.find("\n.\n") != std::string::npos) {
                            handle_send(client_socket_fd, request, mailspool_path);
                            method = "";
                            request = "";
                        }
                    } else if (method == "LIST") {
                        if (lines >= 2) {
                            handle_list(client_socket_fd, request, mailspool_path);
                            method = "";
                            request = "";
                        }
                    } else if (method == "READ") {
                        if (lines >= 3) {
                            handle_read(client_socket_fd, request, mailspool_path);
                            method = "";
                            request = "";
                        }
                    } else if (method == "DEL") {
                        if (lines >= 3) {
                            handle_del(client_socket_fd, request, mailspool_path);
                            method = "";
                            request = "";
                        }
                    } else if (method == "QUIT") {
                        break;
                    } else {
                        auto response = "ERR\n";
                        send(client_socket_fd, response, strlen(response), 0);
                        method = "";
                        request = "";
                    }
                }

            } else if (size == 0) {
                std::cout << "Client closed remote socket" << std::endl;
                break;
            } else {
                std::cerr << "recv error";
                return EXIT_FAILURE;
            }
        }
        close(client_socket_fd);
    }

    close(server_socket_fd);
    return EXIT_SUCCESS;
}

static void handle_send(int client_fd, const std::string &request, const std::string &mailspool_path) {
    std::vector<std::string> parts = parse_send(request, '\n');
    if (parts.size() != 5) {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    bool valid = true;

    auto sender = parts[1];
    auto receiver = parts[2];
    auto subject = parts[3];
    auto message = parts[4];

    if (sender.empty() || sender.size() > 8) valid = false;
    if (receiver.empty() || receiver.size() > 8) valid = false;
    if (subject.empty() || subject.size() > 80) valid = false;

    if (!valid) {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    int mail_counter = 1;

    auto directory = mailspool_path + "/" + receiver;
    auto counter_path = directory + "/.counter";

    std::ifstream counter_input(counter_path);
    if (!counter_input.is_open()) {
        counter_input.close();
        int out = mkdir(directory.c_str(), 0777);
        /*
        if (out != 0) {
            char buffer_2[256];
            char *errorMessage = strerror_r(errno, buffer_2, 256);
            std::cerr << errorMessage << std::endl;
            exit(EXIT_FAILURE);
        }
        */
        std::ofstream counter_output(counter_path);
        auto output = std::to_string(mail_counter);
        counter_output.write(output.c_str(), output.size());

        auto mail_path = directory + "/" + std::to_string(mail_counter);
        std::ofstream mail(mail_path);
        mail << sender << "\n" << receiver << "\n" << subject << "\n" << message;
        mail.close();
        counter_output.close();
    } else {
        std::string string_counter;
        counter_input >> string_counter;
        mail_counter = std::stoi(string_counter);
        mail_counter++;
        counter_input.close();

        std::ofstream counter_output(counter_path);
        counter_output << std::to_string(mail_counter);

        auto mail_path = directory + "/" + std::to_string(mail_counter);
        std::ofstream mail(mail_path);
        mail << sender << "\n" << receiver << "\n" << subject << "\n" << message;
        mail.close();
        counter_output.close();
    }

    auto response = "OK\n";
    send(client_fd, response, strlen(response), 0);
}

static void handle_list(int client_fd, const std::string &request, const std::string &mailspool_path) {
    std::vector<std::string> parts = parse_list(request, '\n');
    if (parts.size() != 2) {
        auto response = "Invalid Request\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    bool valid = true;

    auto user = parts[1];

    if (user.empty() || user.size() > 8) valid = false;

    if (!valid) {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    int mail_counter = 0;
    std::vector<std::string> subjects;

    auto directory = mailspool_path + "/" + user;
    auto counter_path = directory + "/.counter";

    std::ifstream counter_input(counter_path);
    if (counter_input.is_open()) {
        std::string string_counter;
        counter_input >> string_counter;
        mail_counter = std::stoi(string_counter);

        for (int i = 1; i <= mail_counter; i++) {
            auto mail_path = directory + "/" + std::to_string(i);
            std::ifstream mail(mail_path);
            std::stringstream buffer;
            buffer << mail.rdbuf();
            std::string mail_content = buffer.str();

            unsigned long first = mail_content.find('\n');
            unsigned long second = mail_content.find('\n', first + 1);
            unsigned long third = mail_content.find('\n', second + 1);
            subjects.push_back(mail_content.substr(second + 1, third - second - 1));
            mail.close();
        }
    }

    counter_input.close();

    std::string response = "OK\n";
    response.append(std::to_string(mail_counter) + "\n");

    for (const auto &subject : subjects) {
        response.append(subject + "\n");
    }

    send(client_fd, response.c_str(), response.size(), 0);
}


static void handle_read(int client_fd, const std::string &request, const std::string &mailspool_path) {
    std::vector<std::string> parts = parse_read(request, '\n');
    if (parts.size() != 3) {
        auto response = "Invalid Request\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    bool valid = true;

    auto user = parts[1];
    auto message_nr = parts[2];

    if (user.empty() || user.size() > 8) valid = false;

    if (!valid) {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    auto directory = mailspool_path + "/" + user;
    auto mail_path = directory + "/" + message_nr;

    std::ifstream mail(mail_path);
    if (mail.is_open()) {
        std::stringstream buffer;
        buffer << mail.rdbuf();

        std::string response = "OK\n" + buffer.str();
        send(client_fd, response.c_str(), response.size(), 0);
    } else {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
    }
}


static void handle_del(int client_fd, const std::string &request, const std::string &mailspool_path) {
    std::vector<std::string> parts = parse_del(request, '\n');
    if (parts.size() != 3) {
        auto response = "Invalid Request\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    bool valid = true;

    auto user = parts[1];
    auto message_nr = parts[2];

    if (user.empty() || user.size() > 8) valid = false;

    if (!valid) {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
        return;
    }

    auto directory = mailspool_path + "/" + user;
    auto mail_path = directory + "/" + message_nr;

    struct stat info{};

    if (stat(mail_path.c_str(), &info) == 0) {
        remove(mail_path.c_str());
        auto response = "OK\n";
        send(client_fd, response, strlen(response), 0);
    } else {
        auto response = "ERR\n";
        send(client_fd, response, strlen(response), 0);
    }
}


static std::string get_method(const std::string &string, char delimiter) {
    unsigned long position_end = string.find(delimiter, 0);
    if (position_end != std::string::npos) {
        return string.substr(0, position_end);
    }
    return "";
}


static inline int count_lines(const std::string &s) {
    int counter = 0;
    unsigned long begin = 0;
    while (true) {
        auto end = s.find('\n', begin);
        if (end == std::string::npos) break;
        counter++;
        begin = end + 1;
    }
    return counter;
}


// parse and split request for SEND
static std::vector<std::string> parse_send(const std::string &string, char delimiter) {
    std::vector<std::string> parts;
    unsigned long position = 0;

    auto end = string.find("\n.\n");

    if (end == std::string::npos) {
        return parts;
    }

    auto trimmed_string = string.substr(0, end);

    for (int i = 0; i < 5; i++) {
        if (i == 4) {
            parts.push_back(trimmed_string.substr(position, std::string::npos));
            break;
        }

        unsigned long position_end = trimmed_string.find(delimiter, position);
        if (position_end != std::string::npos) {
            parts.push_back(trimmed_string.substr(position, position_end - position));
        } else {
            parts.push_back(trimmed_string.substr(position, position_end));
            break;
        }
        position = position_end + 1;
    }

    if (!parts.empty() && parts.back().empty()) parts.pop_back();

    return parts;
}


// parse and split request for LIST
static std::vector<std::string> parse_list(const std::string &string, char delimiter) {
    std::vector<std::string> parts{};
    unsigned long position = 0;

    auto trimmed_string = string;
    trim(trimmed_string);

    for (int i = 0; i < 2; i++) {
        if (i == 1) {
            parts.push_back(trimmed_string.substr(position, std::string::npos));
            break;
        }

        unsigned long position_end = trimmed_string.find(delimiter, position);
        if (position_end != std::string::npos) {
            parts.push_back(trimmed_string.substr(position, position_end - position));
        } else {
            parts.push_back(trimmed_string.substr(position, position_end));
            break;
        }
        position = position_end + 1;
    }

    if (!parts.empty() && parts.back().empty()) parts.pop_back();

    return parts;
}


// parse and split request for READ
static std::vector<std::string> parse_read(const std::string &string, char delimiter) {
    std::vector<std::string> parts{};
    unsigned long position = 0;

    auto trimmed_string = string;
    trim(trimmed_string);

    for (int i = 0; i < 3; i++) {
        if (i == 2) {
            parts.push_back(trimmed_string.substr(position, std::string::npos));
            break;
        }

        unsigned long position_end = trimmed_string.find(delimiter, position);
        if (position_end != std::string::npos) {
            parts.push_back(trimmed_string.substr(position, position_end - position));
        } else {
            parts.push_back(trimmed_string.substr(position, position_end));
            break;
        }
        position = position_end + 1;
    }

    if (!parts.empty() && parts.back().empty()) parts.pop_back();

    return parts;
}


// parse and split request for DEL
static std::vector<std::string> parse_del(const std::string &string, char delimiter) {
    std::vector<std::string> parts{};
    unsigned long position = 0;

    auto trimmed_string = string;
    trim(trimmed_string);

    for (int i = 0; i < 3; i++) {
        if (i == 2) {
            parts.push_back(trimmed_string.substr(position, std::string::npos));
            break;
        }

        unsigned long position_end = trimmed_string.find(delimiter, position);
        if (position_end != std::string::npos) {
            parts.push_back(trimmed_string.substr(position, position_end - position));
        } else {
            parts.push_back(trimmed_string.substr(position, position_end));
            break;
        }
        position = position_end + 1;
    }

    if (!parts.empty() && parts.back().empty()) parts.pop_back();

    return parts;
}


// trim from left
static inline std::string &ltrim(std::string &s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
    return s;
}


// trim from right
static inline std::string &rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
    return s;
}


// trim from both ends
static inline std::string &trim(std::string &s) {
    return ltrim(rtrim(s));
}

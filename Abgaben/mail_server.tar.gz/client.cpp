#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <iosfwd>
#include <string>
#include <iostream>

#define BUF 1024
#define PORT 6543

static inline int count_lines(const std::string &s) {
    int counter = 0;
    unsigned long begin = 0;
    while (true) {
        auto end = s.find('\n', begin);
        if (end == std::string::npos) break;
        counter++;
        begin = end + 1;
    }
    return counter;
}

int main(int argc, char **argv) {
    int create_socket;
    char buffer[BUF];
    struct sockaddr_in address;
    int size;

    if (argc < 2) {
        printf("Usage: %s ServerAdresse\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if ((create_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Socket error");
        return EXIT_FAILURE;
    }

    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    inet_aton(argv[1], &address.sin_addr);

    if (connect(create_socket, (struct sockaddr *) &address, sizeof(address)) == 0) {
        printf("Connection with server (%s) established\n", inet_ntoa(address.sin_addr));
        size = recv(create_socket, buffer, BUF - 1, 0);
        if (size > 0) {
            buffer[size] = '\0';
            printf("%s", buffer);
        }
    } else {
        perror("Connect error - no server available");
        return EXIT_FAILURE;
    }

    do {
        char buffer[BUF];
        printf("Send message: ");
        fgets(buffer, BUF, stdin);
        std::cout << "input: " << buffer << std::endl;

        // duplicate input
        // to lower case
        // check command
        char bufferCpy[BUF];
        strncpy(bufferCpy, buffer, strlen(buffer));
        for (int i = 0; bufferCpy[i]; i++) {
            bufferCpy[i] = tolower(bufferCpy[i]);
        }
        std::cout << "lower: " << bufferCpy << std::endl;

        if (strcmp(bufferCpy, "send\n") == 1) {
            // check equals 'send'
            do {
                // read lines as long as input is equal to an empty line
                fgets(bufferCpy, BUF, stdin);
                if (strcmp(bufferCpy, "\n") == 1)
                    break;
                send(create_socket, bufferCpy, strlen(bufferCpy), 0);
            } while (1);
        } else if (strcmp(bufferCpy, "del\n") == 1 || strcmp(bufferCpy, "read\n") == 1) {
            // check equals 'del' or 'read'
            // 2 input lines (username, msg-id)
            printf("Username: ");
            fgets(bufferCpy, BUF, stdin);
            send(create_socket, bufferCpy, strlen(bufferCpy), 0);
            printf("Message: ");
            fgets(bufferCpy, BUF, stdin);
            send(create_socket, bufferCpy, strlen(bufferCpy), 0);
        } else if (strcmp(bufferCpy, "list\n") == 1) {
            // check equals 'list'
            // 1 input line (username)
            printf("Username: ");
            fgets(bufferCpy, BUF, stdin);
            send(create_socket, bufferCpy, strlen(bufferCpy), 0);
        }

        send(create_socket, buffer, strlen(buffer), 0);

        // RESPONSE
        /*
        std::string response;
        std::string method;
        int size1 = recv(create_socket, buffer, BUF - 1, 0);

        if (size1 > 0) {
            buffer[size1] = '\0';
            response.append(buffer);
            int lines = count_lines(response);
            std::cout << response;
        }
        */
    } while (strcmp(buffer, "quit\n") != 0);
    close(create_socket);
    return EXIT_SUCCESS;
}


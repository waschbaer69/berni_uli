// message.cpp

#include <string>
#include <iostream>
#include <sstream>
#include <cstring>
#include <fstream>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctime>

#include "message.h"

message::message(std::string completeMessage) {
    //writes the message-content to the class variables
    std::stringstream messageStream;
    std::string str;
    messageStream << completeMessage;

    std::getline(messageStream,str); //SEND

    std::getline(messageStream,sender);
    std::getline(messageStream,reciever);
    std::getline(messageStream,subject);

    while(std::getline(messageStream,str)){
        content=content+str+"\n";
    }

    message_filename = "";

}

message::message(std::string filename, int file) {
    //writes the message-content to the class variables from a file
    std::string str;
    std::stringstream messageStream;

    std::ifstream in_file (filename);

    std::getline(in_file,str);
    sender = str.substr(7);
    std::getline(in_file,str);
    reciever = str.substr(9);
    std::getline(in_file,str);
    subject = str.substr(8);

    std::getline(in_file,str); //"message content:"
    while(std::getline(in_file,str)){
        content=content+str+"\n";
    }
    
    in_file.close();

    message_filename = filename;

}

message::~message() {
}
//some getters:
std::string message::get_sender() {
    return sender;
}

std::string message::get_reciever() {
    return reciever;
}

std::string message::get_subject() {
    return subject;
}

std::string message::get_content() {
    return content;
}

std::string message::get_filename() {
    return message_filename;
}
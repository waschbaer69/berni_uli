// message.h

#ifndef VSYS_MESSAGE_H
#define VSYS_MESSAGE_H

#include <string>

class message {
private:
    std::string sender;
    std::string reciever;
    std::string subject;
    std::string content;
    std::string message_filename;
public:
    message(std::string completeMessage);
    message(std::string messageSender, int file);
    ~message();

    std::string get_sender();
    std::string get_reciever();
    std::string get_subject();
    std::string get_content();

    std::string get_filename();

    void save();
    
};

#endif //VSYS_MESSAGE_H

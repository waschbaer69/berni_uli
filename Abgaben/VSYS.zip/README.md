# VSYS

Example for server/client connection via sockets

Files:
* myserver.cpp

  Contains the basic loop of the server

* server.h

  Contain declaration of the server class

* server.cpp

  Contain Implementation of the server class

* message.h

  Contain declaration of the message class

* message.cpp

  Contain Implementation of the message class

* mycient.cpp

  Contains the basic operations of the client

* Makefile

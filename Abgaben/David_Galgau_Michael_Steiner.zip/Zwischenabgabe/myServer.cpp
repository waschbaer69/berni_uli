/*
 * Authors: David Galgau, Michael Steiner
 * Date: 18.10.2017
 * myserver.c */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
//#include <string.h>
#include <cstring>
#include <string>
#include <iostream>
#include <fstream>

#define BUF 1024
#define PORT 6543

using namespace std;

void sendMessage(char *buffer, int new_socket)
{

    send(new_socket, buffer, strlen(buffer),0);
}
void sendMessage(std::string message, int new_socket)
{
    //SIGSEGV
    char* bufferKuchen;
    strcpy(bufferKuchen, message.c_str());
    send(new_socket, bufferKuchen, strlen(bufferKuchen),0);
}

std::string receiveMessage(int create_socket)
{
    char buffer[BUF];
    int size=recv(create_socket,buffer,BUF-1, 0);
    if (size>0)
    {
        buffer[size]= '\0';
        std::string myCppString = "";
        return myCppString = buffer;
    }
    return "WRONG INPUT";

}


void addMessageToFile(char* fileName, std::string senderName, std::string receiverName, std::string receiveSubject, std::string receiverMessage){
    fstream myfile;

    myfile.open (senderName.substr(0, senderName.length()-1), std::fstream::in | std::fstream::out | std::fstream::app);
    myfile << senderName;
    myfile << receiverName;
    myfile << receiveSubject;
    myfile << receiverMessage + "\n.\n";
    myfile.close();
}

void readMessageFromFile(std::string fileName, int new_socket){

    ifstream myfile (fileName.substr(0, fileName.length()-1));
    string line;
    if (myfile.is_open())
    {
        while ( getline (myfile,line) )
        {
            cout << line << '\n';
            sendMessage(line, new_socket);
        }
        myfile.close();
    }
}



int main (int argc, char *argv[]) {
    int create_socket, new_socket;
    socklen_t addrlen;
    char buffer[BUF];
    int size;
    struct sockaddr_in address, cliaddress;

    if( argc < 3 ){
        printf("Usage: %s ServerAdresse VerzeichnisPfad\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    create_socket = socket (AF_INET, SOCK_STREAM, 0);

    memset(&address,0,sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons (PORT);

    if (bind ( create_socket, (struct sockaddr *) &address, sizeof (address)) != 0) {
        perror("bind error");
        return EXIT_FAILURE;
    }
    listen (create_socket, 5);

    addrlen = sizeof (struct sockaddr_in);

    while (1) {
        printf("Waiting for connections...\n");
        new_socket = accept ( create_socket, (struct sockaddr *) &cliaddress, &addrlen );
        if (new_socket > 0)
        {
            printf ("Client connected from %s:%d...\n", inet_ntoa (cliaddress.sin_addr),ntohs(cliaddress.sin_port));

        }
        do {
            strcpy(buffer,"Welcome to myserver, Please enter your command: SEND | LIST | READ | DEL | QUIT\n:");
            //send(new_socket, buffer, strlen(buffer),0);
            sendMessage(buffer, new_socket);

            size = recv (new_socket, buffer, BUF-1, 0);
            if( size > 0)
            {
                buffer[size] = '\0';
                printf ("Message received: %s\n", buffer);

                std::string myCppString = "";
                myCppString = buffer;


                if(myCppString == "SEND\n"){
                    std::string senderName = "";
                    std::string receiverName = "";
                    std::string receiveSubject = "";
                    std::string receiverMessage = "";
                    sendMessage("Please enter your Name: \n", new_socket);
                    senderName = receiveMessage(new_socket);
                    sendMessage("Please enter your destination: \n", new_socket);
                    receiverName = receiveMessage(new_socket);
                    sendMessage("Enter your subject: \n", new_socket);
                    receiveSubject = receiveMessage(new_socket);
                    sendMessage("Enter Message: \n", new_socket);
                    receiverMessage = receiveMessage(new_socket);

                    addMessageToFile("ich", senderName, receiverName, receiveSubject, receiverMessage);
                    sendMessage("Message sent!\n", new_socket);

                }
                else if(myCppString == "LIST\n"){

                }
                else if(myCppString == "DEL\n"){

                }
                else if(myCppString == "READ\n"){
                    std::string senderName = "";
                    sendMessage("Please enter your Name: \n", new_socket);
                    senderName = receiveMessage(new_socket);

                    readMessageFromFile(senderName, new_socket);
                }
                else if(myCppString == "QUIT\n"){

                }
                cout << myCppString << endl;
                myCppString = "";

            }
            else if (size == 0)
            {
                printf("Client closed remote socket\n");
                break;
            }
            else
            {
                perror("recv error");
                return EXIT_FAILURE;
            }
        } while (strncmp (buffer, "QUIT\n", 4)  != 0);
        close (new_socket);
    }
    close (create_socket);
    return EXIT_SUCCESS;
}

